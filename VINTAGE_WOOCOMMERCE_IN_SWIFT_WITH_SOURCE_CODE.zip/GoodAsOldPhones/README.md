GoodAsOldPhones
==========

GoodAsOldPhones is the demo app of [Swift tutorial](https://www.codeschool.com/courses/app-evolution-with-swift) on code school. This app demonstates basic use and implementation of tab bar controller, navigation controller, scoll view, table view and storyboard.

## Screenshots
![GoodAsOldPhones](./GoodAsOldPhones.gif)
